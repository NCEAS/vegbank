The stems.csv is the "original" stems file.
stems_alt.csv has been hand created to convert the dbh size classes into the VegBank fields: stemDiameter and stemDiameterAccuracy (and add label for cells: stemCount)
stems_alt_NRMd.csv is the output normalized file.